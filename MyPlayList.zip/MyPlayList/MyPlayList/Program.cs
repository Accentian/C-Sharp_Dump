﻿using System;

namespace MyPlayList
{
    class Program
    {
        static void Main(string[] args)
        {
            Album album1 = new Album("Tattoo", "Rolling Stones", "Rock", 600000);
            album1.copySold();

            Album album2 = new Album("Their Greatest Hits", "Eagles", "Classic Rock", 38000000);
            album2.copySold();

            Album album3 = new Album("Thriller", "Micheal Jackson", "Classic Rock", 35000000);
            album3.copySold();

            Album album4 = new Album("The Wall", "Pink Floyd", "Classic Rock", 22000000);
            album4.copySold();

            // Pause
            Console.ReadLine();


        } // End main


    } // End class

    class Album
    {
        private string title;
        private string artist;
        private string genre;
        private double copies;
        private double cost_of_album = 35;
        private double total;

        // Constructor
        public Album (string title, string artist, string genre, double copies)
        {
            this.title = title;
            this.artist = artist;
            this.genre = genre;
            this.copies = copies;
        }

        // Getters and Setters
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        public string Artist
        {
            get { return artist; }
            set { artist = value; }
        }
        public string Genre
        {
            get { return genre; }
            set { genre = value; }
        }
        public double Copies
        {
            get { return copies; }
            set { copies = value; }
        }

        // Method
        public void copySold()
        {
            total = copies * cost_of_album;
            printInfo(total);
        }

        public void printInfo(double total)
        {
            Console.WriteLine("The album " + title + " by the " + artist + ", a "
                + genre + " group, made $" + total);
        }

    } // End Album class

} // End namespace
